package com.example.reviewagent;

import com.example.reviewagent.model.ReviewFinding;
import org.junit.jupiter.api.Test;

import java.lang.reflect.Method;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Exercises the ReviewParsing helper via reflection since it's package-private.
 * In a real project, consider making it package-visible-for-testing or moving
 * the test into the same package (as done here) and dropping the reflection.
 */
class ReviewParsingTest {

    @Test
    void parsesWellFormedResponse() throws Exception {
        String raw = """
                SUMMARY: No hardcoded secrets found
                PASSED: true
                DETAILS:
                - Checked all changed files
                - No issues found
                """;

        Class<?> clazz = Class.forName("com.example.reviewagent.workflow.ReviewParsing");
        Method parse = clazz.getDeclaredMethod("parse", String.class, String.class);
        parse.setAccessible(true);

        ReviewFinding finding = (ReviewFinding) parse.invoke(null, "Security", raw);

        assertEquals("Security", finding.category());
        assertEquals("No hardcoded secrets found", finding.summary());
        assertTrue(finding.passed());
        assertTrue(finding.details().contains("No issues found"));
    }
}
