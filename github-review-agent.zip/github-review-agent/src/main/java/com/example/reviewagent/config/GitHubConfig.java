package com.example.reviewagent.config;

import org.kohsuke.github.GitHub;
import org.kohsuke.github.GitHubBuilder;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.io.IOException;

@Configuration
@EnableConfigurationProperties(GitHubProperties.class)
public class GitHubConfig {

    @Bean
    public GitHub github(GitHubProperties properties) throws IOException {
        return new GitHubBuilder()
                .withOAuthToken(properties.token())
                .build();
    }
}
