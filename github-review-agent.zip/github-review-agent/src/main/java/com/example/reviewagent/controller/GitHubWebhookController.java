package com.example.reviewagent.controller;

import com.example.reviewagent.config.GitHubProperties;
import com.example.reviewagent.model.GitHubWebhookPayload;
import com.example.reviewagent.service.CodeReviewService;
import com.example.reviewagent.service.WebhookSignatureVerifier;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.io.IOException;
import java.util.Set;

@RestController
@RequestMapping("/webhooks/github")
public class GitHubWebhookController {

    private static final Logger log = LoggerFactory.getLogger(GitHubWebhookController.class);
    private static final Set<String> TRIGGER_ACTIONS = Set.of("opened", "synchronize", "reopened");

    private final CodeReviewService reviewService;
    private final WebhookSignatureVerifier signatureVerifier;
    private final ObjectMapper objectMapper;
    private final GitHubProperties gitHubProperties;

    public GitHubWebhookController(CodeReviewService reviewService,
                                    WebhookSignatureVerifier signatureVerifier,
                                    ObjectMapper objectMapper,
                                    GitHubProperties gitHubProperties) {
        this.reviewService = reviewService;
        this.signatureVerifier = signatureVerifier;
        this.objectMapper = objectMapper;
        this.gitHubProperties = gitHubProperties;
    }

    @PostMapping
    public ResponseEntity<String> handleWebhook(
            @RequestHeader("X-GitHub-Event") String event,
            @RequestHeader(value = "X-Hub-Signature-256", required = false) String signature,
            @RequestBody String rawBody) throws IOException {

        if (!signatureVerifier.isValid(rawBody, signature, gitHubProperties.webhookSecret())) {
            log.warn("Rejected webhook with invalid signature");
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Invalid signature");
        }

        if (!"pull_request".equals(event)) {
            return ResponseEntity.ok("Event ignored: " + event);
        }

        GitHubWebhookPayload payload = objectMapper.readValue(rawBody, GitHubWebhookPayload.class);

        if (!TRIGGER_ACTIONS.contains(payload.action())) {
            return ResponseEntity.ok("Action ignored: " + payload.action());
        }

        String owner = payload.repository().owner().login();
        String repo = payload.repository().name();
        int prNumber = payload.pullRequest().number();

        log.info("Starting review for {}/{} PR #{}", owner, repo, prNumber);

        // Respond immediately; run the review async so GitHub's webhook delivery
        // doesn't time out waiting on multiple LLM calls.
        reviewService.reviewPullRequestAsync(owner, repo, prNumber);

        return ResponseEntity.accepted().body("Review started for PR #" + prNumber);
    }
}
