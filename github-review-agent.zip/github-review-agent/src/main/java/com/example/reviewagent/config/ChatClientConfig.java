package com.example.reviewagent.config;

import com.example.reviewagent.tools.GitHubTools;
import org.springframework.ai.chat.client.ChatClient;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * We expose a single reusable ChatClient.Builder-backed prototype and let each
 * workflow node (security / style / test-coverage) call .prompt().system(...) with
 * its own scoped instructions at call time. This keeps one shared tool registry
 * (GitHubTools) while letting each "agent" behave differently.
 */
@Configuration
public class ChatClientConfig {

    @Bean
    public ChatClient reviewChatClient(ChatClient.Builder builder, GitHubTools githubTools) {
        return builder
                .defaultTools(githubTools)
                .build();
    }
}
