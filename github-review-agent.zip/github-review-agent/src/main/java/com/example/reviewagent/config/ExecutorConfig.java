package com.example.reviewagent.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

import java.util.concurrent.Executor;

@Configuration
public class ExecutorConfig {

    /**
     * Dedicated pool for the three parallel review calls. Sized to 3 since that's
     * the current fan-out width; bump this if you add more parallel review nodes.
     */
    @Bean
    public Executor reviewExecutor() {
        ThreadPoolTaskExecutor executor = new ThreadPoolTaskExecutor();
        executor.setCorePoolSize(3);
        executor.setMaxPoolSize(6);
        executor.setThreadNamePrefix("review-node-");
        executor.initialize();
        return executor;
    }
}
