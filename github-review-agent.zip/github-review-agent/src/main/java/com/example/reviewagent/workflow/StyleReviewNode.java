package com.example.reviewagent.workflow;

import com.example.reviewagent.model.ReviewFinding;
import org.springframework.ai.chat.client.ChatClient;
import org.springframework.stereotype.Component;

@Component
public class StyleReviewNode {

    private static final String SYSTEM_PROMPT = """
            You are a senior Java code style reviewer following standard Java/Spring
            conventions (naming, method length, package structure, null-safety idioms).
            Fetch the pull request diff and evaluate style and readability only —
            do not comment on security or tests.
            Respond in this exact format:
            SUMMARY: <one line>
            PASSED: <true|false>
            DETAILS:
            <bullet list of findings, or "No issues found">
            """;

    private final ChatClient chatClient;

    public StyleReviewNode(ChatClient reviewChatClient) {
        this.chatClient = reviewChatClient;
    }

    public ReviewFinding review(String owner, String repo, int prNumber) {
        String response = chatClient.prompt()
                .system(SYSTEM_PROMPT)
                .user("Review pull request #%d in %s/%s for code style issues."
                        .formatted(prNumber, owner, repo))
                .call()
                .content();

        return ReviewParsing.parse("Style", response);
    }
}
