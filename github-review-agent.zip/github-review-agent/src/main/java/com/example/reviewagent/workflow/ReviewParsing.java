package com.example.reviewagent.workflow;

import com.example.reviewagent.model.ReviewFinding;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Parses the SUMMARY / PASSED / DETAILS format each review node's system
 * prompt asks the model to follow. In production, prefer Spring AI's
 * structured output converter (BeanOutputConverter) over regex parsing —
 * this is kept simple here for clarity.
 */
final class ReviewParsing {

    private static final Pattern SUMMARY = Pattern.compile("SUMMARY:\\s*(.+)");
    private static final Pattern PASSED = Pattern.compile("PASSED:\\s*(true|false)", Pattern.CASE_INSENSITIVE);
    private static final Pattern DETAILS = Pattern.compile("DETAILS:\\s*([\\s\\S]*)");

    private ReviewParsing() {
    }

    static ReviewFinding parse(String category, String raw) {
        String summary = extract(SUMMARY, raw, "No summary provided");
        boolean passed = extract(PASSED, raw, "false").equalsIgnoreCase("true");
        String details = extract(DETAILS, raw, raw).trim();

        return new ReviewFinding(category, summary.trim(), details, passed);
    }

    private static String extract(Pattern pattern, String raw, String fallback) {
        Matcher matcher = pattern.matcher(raw);
        return matcher.find() ? matcher.group(1) : fallback;
    }
}
