package com.example.reviewagent.workflow;

import com.example.reviewagent.model.ReviewFinding;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Executor;
import java.util.stream.Collectors;

/**
 * Fan-out to the three review nodes in parallel, then fan-in the results into
 * a single merged comment.
 *
 * This plays the role LangGraph4j's StateGraph would play for a linear/branching
 * workflow, but since these three checks are independent (no data dependency
 * between them), a plain CompletableFuture fan-out/fan-in is simpler and avoids
 * an extra dependency. If you later need conditional branching, retries, or a
 * pause-for-human-approval step, that's the point to introduce LangGraph4j,
 * Spring Statemachine, or Temporal instead — see the class-level comment in
 * ReviewAgentApplication for guidance on when to make that switch.
 */
@Component
public class ReviewOrchestrator {

    private final SecurityReviewNode securityNode;
    private final StyleReviewNode styleNode;
    private final TestCoverageReviewNode testCoverageNode;
    private final Executor reviewExecutor;

    public ReviewOrchestrator(SecurityReviewNode securityNode,
                               StyleReviewNode styleNode,
                               TestCoverageReviewNode testCoverageNode,
                               Executor reviewExecutor) {
        this.securityNode = securityNode;
        this.styleNode = styleNode;
        this.testCoverageNode = testCoverageNode;
        this.reviewExecutor = reviewExecutor;
    }

    public List<ReviewFinding> runParallelReview(String owner, String repo, int prNumber) {
        CompletableFuture<ReviewFinding> security = CompletableFuture.supplyAsync(
                () -> securityNode.review(owner, repo, prNumber), reviewExecutor);

        CompletableFuture<ReviewFinding> style = CompletableFuture.supplyAsync(
                () -> styleNode.review(owner, repo, prNumber), reviewExecutor);

        CompletableFuture<ReviewFinding> testCoverage = CompletableFuture.supplyAsync(
                () -> testCoverageNode.review(owner, repo, prNumber), reviewExecutor);

        return CompletableFuture.allOf(security, style, testCoverage)
                .thenApply(v -> List.of(security.join(), style.join(), testCoverage.join()))
                .join();
    }

    public String mergeIntoComment(List<ReviewFinding> findings) {
        boolean allPassed = findings.stream().allMatch(ReviewFinding::passed);

        String header = allPassed
                ? "## ✅ Automated Review: No blocking issues found\n"
                : "## ⚠️ Automated Review: Issues found\n";

        String body = findings.stream()
                .map(f -> """
                        ### %s %s
                        **%s**

                        %s
                        """.formatted(f.passed() ? "✅" : "❌", f.category(), f.summary(), f.details()))
                .collect(Collectors.joining("\n---\n"));

        return header + "\n" + body;
    }
}
