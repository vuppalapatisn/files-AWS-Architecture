package com.example.reviewagent.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Minimal subset of GitHub's pull_request webhook payload.
 * Extend as needed — GitHub sends many more fields than this.
 * https://docs.github.com/en/webhooks/webhook-events-and-payloads#pull_request
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public record GitHubWebhookPayload(
        String action,
        @JsonProperty("pull_request") PullRequest pullRequest,
        Repository repository
) {
    @JsonIgnoreProperties(ignoreUnknown = true)
    public record PullRequest(int number) {
    }

    @JsonIgnoreProperties(ignoreUnknown = true)
    public record Repository(String name, Owner owner) {
    }

    @JsonIgnoreProperties(ignoreUnknown = true)
    public record Owner(String login) {
    }
}
