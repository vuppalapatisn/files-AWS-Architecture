package com.example.reviewagent.tools;

import org.kohsuke.github.GHContent;
import org.kohsuke.github.GHPullRequest;
import org.kohsuke.github.GHPullRequestFileDetail;
import org.kohsuke.github.GitHub;
import org.springframework.ai.tool.annotation.Tool;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.util.stream.Collectors;

/**
 * GitHub actions exposed to the LLM as callable tools.
 * Each @Tool description is the "API contract" the model reads to decide
 * when and how to call the method — keep these precise.
 */
@Component
public class GitHubTools {

    private final GitHub github;

    public GitHubTools(GitHub github) {
        this.github = github;
    }

    @Tool(description = "Get the diff/patch for every changed file in a pull request, " +
            "including filenames and line-level changes")
    public String getPullRequestDiff(String owner, String repo, int prNumber) throws IOException {
        GHPullRequest pr = github.getRepository(owner + "/" + repo).getPullRequest(prNumber);
        StringBuilder diff = new StringBuilder();
        for (GHPullRequestFileDetail file : pr.listFiles()) {
            diff.append("File: ").append(file.getFilename()).append("\n");
            diff.append("Status: ").append(file.getStatus()).append("\n");
            if (file.getPatch() != null) {
                diff.append(file.getPatch());
            }
            diff.append("\n\n");
        }
        return diff.toString();
    }

    @Tool(description = "Get the full content of a specific file in the repository at a given git ref " +
            "(branch name, tag, or commit SHA). Use this when the diff alone isn't enough context.")
    public String getFileContent(String owner, String repo, String path, String ref) throws IOException {
        GHContent content = github.getRepository(owner + "/" + repo).getFileContent(path, ref);
        return content.getContent();
    }

    @Tool(description = "List the file paths that were changed, added, or deleted in a pull request")
    public String listChangedFiles(String owner, String repo, int prNumber) throws IOException {
        GHPullRequest pr = github.getRepository(owner + "/" + repo).getPullRequest(prNumber);
        return pr.listFiles().toList().stream()
                .map(f -> f.getFilename() + " (" + f.getStatus() + ")")
                .collect(Collectors.joining("\n"));
    }

    @Tool(description = "Post a single review comment on a pull request with the given body text")
    public String postReviewComment(String owner, String repo, int prNumber, String body) throws IOException {
        GHPullRequest pr = github.getRepository(owner + "/" + repo).getPullRequest(prNumber);
        pr.comment(body);
        return "Comment posted successfully on PR #" + prNumber;
    }
}
