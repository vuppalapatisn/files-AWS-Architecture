package com.example.reviewagent.model;

/**
 * The output of one review node (security / style / test-coverage).
 *
 * @param category    which check produced this, e.g. "Security"
 * @param summary     one-line summary of the finding
 * @param details     full findings text from the LLM
 * @param passed      true if no significant issues were found
 */
public record ReviewFinding(String category, String summary, String details, boolean passed) {
}
