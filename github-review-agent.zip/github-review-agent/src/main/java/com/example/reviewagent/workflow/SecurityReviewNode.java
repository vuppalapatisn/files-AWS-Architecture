package com.example.reviewagent.workflow;

import com.example.reviewagent.model.ReviewFinding;
import org.springframework.ai.chat.client.ChatClient;
import org.springframework.stereotype.Component;

@Component
public class SecurityReviewNode {

    private static final String SYSTEM_PROMPT = """
            You are a senior application security reviewer.
            Fetch the pull request diff, then check for:
            - Injection risks (SQL, command, deserialization)
            - Hardcoded secrets or credentials
            - Missing input validation or authorization checks
            - Unsafe use of external input (paths, URLs, headers)
            If you need more context on a file, fetch its full content.
            Respond in this exact format:
            SUMMARY: <one line>
            PASSED: <true|false>
            DETAILS:
            <bullet list of findings, or "No issues found">
            """;

    private final ChatClient chatClient;

    public SecurityReviewNode(ChatClient reviewChatClient) {
        this.chatClient = reviewChatClient;
    }

    public ReviewFinding review(String owner, String repo, int prNumber) {
        String response = chatClient.prompt()
                .system(SYSTEM_PROMPT)
                .user("Review pull request #%d in %s/%s for security issues."
                        .formatted(prNumber, owner, repo))
                .call()
                .content();

        return ReviewParsing.parse("Security", response);
    }
}
