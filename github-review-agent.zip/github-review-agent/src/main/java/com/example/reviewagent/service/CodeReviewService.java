package com.example.reviewagent.service;

import com.example.reviewagent.model.ReviewFinding;
import com.example.reviewagent.tools.GitHubTools;
import com.example.reviewagent.workflow.ReviewOrchestrator;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.util.List;

@Service
public class CodeReviewService {

    private static final Logger log = LoggerFactory.getLogger(CodeReviewService.class);

    private final ReviewOrchestrator orchestrator;
    private final GitHubTools githubTools;

    public CodeReviewService(ReviewOrchestrator orchestrator, GitHubTools githubTools) {
        this.orchestrator = orchestrator;
        this.githubTools = githubTools;
    }

    /**
     * Synchronous entry point — useful for tests or a manual "review this PR" endpoint.
     */
    public String reviewPullRequest(String owner, String repo, int prNumber) throws IOException {
        List<ReviewFinding> findings = orchestrator.runParallelReview(owner, repo, prNumber);
        String comment = orchestrator.mergeIntoComment(findings);
        githubTools.postReviewComment(owner, repo, prNumber, comment);
        return comment;
    }

    /**
     * Fire-and-forget entry point for the webhook, so GitHub's webhook delivery
     * (which times out after ~10s) doesn't wait on multiple LLM calls.
     * Requires @EnableAsync on a @Configuration class (see AsyncConfig).
     */
    @Async
    public void reviewPullRequestAsync(String owner, String repo, int prNumber) {
        try {
            reviewPullRequest(owner, repo, prNumber);
        } catch (IOException e) {
            log.error("Review failed for {}/{} PR #{}", owner, repo, prNumber, e);
        }
    }
}
