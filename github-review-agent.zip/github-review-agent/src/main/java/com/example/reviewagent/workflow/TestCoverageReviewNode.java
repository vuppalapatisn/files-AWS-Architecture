package com.example.reviewagent.workflow;

import com.example.reviewagent.model.ReviewFinding;
import org.springframework.ai.chat.client.ChatClient;
import org.springframework.stereotype.Component;

@Component
public class TestCoverageReviewNode {

    private static final String SYSTEM_PROMPT = """
            You are a test coverage reviewer.
            Fetch the list of changed files and the diff for this pull request.
            Determine whether new or modified production code has corresponding
            new or updated tests in the same PR. Flag any changed public method,
            branch, or edge case that appears untested.
            Respond in this exact format:
            SUMMARY: <one line>
            PASSED: <true|false>
            DETAILS:
            <bullet list of findings, or "No issues found">
            """;

    private final ChatClient chatClient;

    public TestCoverageReviewNode(ChatClient reviewChatClient) {
        this.chatClient = reviewChatClient;
    }

    public ReviewFinding review(String owner, String repo, int prNumber) {
        String response = chatClient.prompt()
                .system(SYSTEM_PROMPT)
                .user("Review pull request #%d in %s/%s for test coverage gaps."
                        .formatted(prNumber, owner, repo))
                .call()
                .content();

        return ReviewParsing.parse("Test Coverage", response);
    }
}
