# GitHub Review Agent (Spring Boot + Spring AI)

Agentic code reviewer that runs three checks in parallel — security, style, and
test coverage — and posts one merged comment on a GitHub pull request.

## Architecture

```
GitHub PR event (webhook)
        │
        ▼
GitHubWebhookController  ──verifies signature──▶ CodeReviewService (async)
        │
        ▼
ReviewOrchestrator (fan-out / fan-in via CompletableFuture)
   ├── SecurityReviewNode      ─┐
   ├── StyleReviewNode          ├─ each: ChatClient + GitHubTools (@Tool)
   └── TestCoverageReviewNode  ─┘
        │
        ▼
mergeIntoComment() → GitHubTools.postReviewComment()
```

Each node is an independent `ChatClient` call scoped with its own system
prompt. They share one `GitHubTools` bean (diff fetching, file content,
posting comments) registered as Spring AI `@Tool` methods — the model decides
which of those to call and in what order within each node's single `.call()`.

## Prerequisites

- Java 17+
- Maven 3.9+
- An OpenAI API key (or swap the starter dependency for Anthropic/Azure/etc.)
- A GitHub personal access token with `repo` scope (or a GitHub App token)
- A public HTTPS URL for the webhook (use `ngrok` for local testing)

## Setup Steps

1. **Unzip and open the project**
   ```bash
   cd github-review-agent
   ```

2. **Set required environment variables**
   ```bash
   export OPENAI_API_KEY=sk-...
   export GITHUB_TOKEN=ghp_...
   export GITHUB_WEBHOOK_SECRET=some-long-random-string
   ```

3. **Build**
   ```bash
   ./mvnw clean package
   ```
   (If you don't have the Maven wrapper jar, run `mvn clean package` with a
   local Maven install instead — see note below.)

4. **Run locally**
   ```bash
   ./mvnw spring-boot:run
   ```
   The app starts on `http://localhost:8080`.

5. **Expose it publicly for GitHub to reach (local dev only)**
   ```bash
   ngrok http 8080
   ```
   Note the `https://xxxx.ngrok-free.app` URL it gives you.

6. **Register the webhook on your GitHub repo**
   - Go to your repo → Settings → Webhooks → Add webhook
   - Payload URL: `https://xxxx.ngrok-free.app/webhooks/github`
   - Content type: `application/json`
   - Secret: the same value as `GITHUB_WEBHOOK_SECRET`
   - Events: select "Pull requests" only
   - Save

7. **Trigger it**
   Open (or push a commit to) a pull request in that repo. Within a few
   seconds you should see a new comment with three sections: Security, Style,
   Test Coverage.

## Notes on the Maven Wrapper

This project references `./mvnw` but the wrapper jar itself isn't included
here to keep the download small. Generate it once with:
```bash
mvn -N wrapper:wrapper
```
or just use your local `mvn` install directly.

## Switching Models

To use Anthropic's Claude instead of OpenAI, replace the dependency in
`pom.xml`:
```xml
<dependency>
    <groupId>org.springframework.ai</groupId>
    <artifactId>spring-ai-anthropic-spring-boot-starter</artifactId>
</dependency>
```
and update `application.yml`:
```yaml
spring:
  ai:
    anthropic:
      api-key: ${ANTHROPIC_API_KEY}
      chat:
        options:
          model: claude-sonnet-4-5
```

## When to Outgrow This Design

The current orchestrator uses plain `CompletableFuture` fan-out/fan-in because
the three checks are independent. Move to a graph-based tool (LangGraph4j,
Spring Statemachine, or Temporal) once you need:
- Conditional branching (e.g., skip test-coverage check for docs-only PRs)
- Retry loops (e.g., re-run security check after a fix commit)
- A pause for human approval mid-workflow
- Durable execution across app restarts for long-running reviews

## Swapping Hand-Rolled Tools for GitHub's Official MCP Server

Instead of maintaining `GitHubTools` yourself, you can point Spring AI at
GitHub's hosted MCP server and skip writing the wrapper methods:
```yaml
spring:
  ai:
    mcp:
      client:
        sse:
          connections:
            github:
              url: https://api.githubcopilot.com/mcp
```
Then inject `ToolCallbackProvider` instead of `GitHubTools` into each review
node's `ChatClient` call.
